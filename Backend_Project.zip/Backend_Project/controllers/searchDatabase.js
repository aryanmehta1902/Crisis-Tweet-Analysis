import axios from 'axios';

const LLAMA_API_URL = "http://llama-api-url"; // Replace with the actual API URL

export const getSearchResults = async (req, res) => {
    try {
        const query = req.query.q;  // Frontend will send this query
        if (!query) return res.status(400).json({ error: "Query parameter is required" });

        // Fetch data from LLaMA/DeSeek
        const response = await axios.post(LLAMA_API_URL, { query });

        // Send back the data to the client
        res.json(response.data);
    } catch (error) {
        console.error("Error fetching data from LLaMA/DeSeek:", error);
        res.status(500).json({ error: "Failed to retrieve data from LLaMA/DeSeek" });
    }
};