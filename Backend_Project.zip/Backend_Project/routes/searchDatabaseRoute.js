import express from 'express';
import { searchEmergencies } from '../controllers/searchController.js';

const router = express.Router();

// API route for searching emergency-related tweets
router.get('/search', searchEmergencies);

export default router;